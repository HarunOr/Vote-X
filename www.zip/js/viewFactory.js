var votex = angular
// Momentan keine Funktion
.module('starter.controllers');
votex.factory('viewFactory', function(){
    var callVote = "false";
    var editVote = "false";
    return this;
	

	
	
});

