firebase-bower
==============

To use firebase via bower, do:

    bower install firebase

NOTE: This repo is automatically generated and is not monitored for issues / pull requests.  Please contact support@firebase.com for any bugs/suggestions on Firebase or the bower module.

LICENSE - Refer to: https://www.firebase.com/terms/terms-of-service.html
